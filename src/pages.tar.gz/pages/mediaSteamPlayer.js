export default class MediaStreamPlayer {}
