import React, { Component } from 'react';

export default class waveSurferDraw extends Component {
  render() {
    return <div></div>;
  }
}
