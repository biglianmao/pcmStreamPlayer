import React, { useState, useEffect, useMemo, useContext, useCallback } from 'react';
// import DashboardMap from '@/components/DashboardMap';
// import ExtensionControlMap from '@/components/AreaMap'
// import request from '@/utils/request';
// import { Chart, Interval, Area, Line, Tooltip, Axis, Coordinate } from 'bizcharts';
// import { Tree, Table, Button, Checkbox, Modal } from 'antd';
// import { CaretRightOutlined, CaretUpOutlined } from '@ant-design/icons';
// import { useSize } from 'ahooks';
// import ProTable from '@/components/ProTable';
// import EchartsShow from './echartsShow';
// import MesInfoModel from './mesPage/index';
import { Base64 } from './js/base64';
import { PCMPlayer } from './js/pcm-player5';
import _ from 'lodash'; // 开启节流

function Index(props) {
  const [getPropsData, setGetPropsData] = useState([]);

  useEffect(() => {
    const player = new PCMPlayer({
      encoding: '16bitInt', // 传入的数据是采用多少位编码，默认16位
      channels: 2, // 声道数
      sampleRate: 8000, // 采样率
      flushingTime: 1000, // 缓存时间 单位 ms
    });
    // 订阅
    const timeId = setInterval(() => {
      fetch(`/api/getpcmr8000c2`)
        .then((res) => res.arrayBuffer())
        .then((data) => {
          //   console.log(data);
          player.feed(data);
        });
    }, 20);

    return () => {
      clearInterval(timeId);
    };
  }, []);

  return (
    <div id="container" style={{ width: '400px', margin: '0 auto' }}>
      <h2>实时音频播放</h2>
      {/* <p>在后台代码中可设置播放文件的路径</p> */}
      <canvas id="myCanvas" width="500" height="300">
        不支持cavans
      </canvas>
    </div>
  );
}

export default Index;
