export function PCMPlayer(option) {
  this.init(option);
}

PCMPlayer.prototype.init = function (option) {
  const defaults = {
    encoding: '16bitInt',
    channels: 1,
    sampleRate: 8000,
    flushingTime: 1000,
  };

  this.option = Object.assign({}, defaults, option);
  this.samples = new Float32Array();
  this.flush = this.flush.bind(this);
  this.interval = setInterval(this.flush.bind(this), this.option.flushingTime);
  this.maxValue = this.getMaxValue();
  this.typedArray = this.getTypedArray();
  this.analyser = null;
  this.frequency = [];
  this.canvas = document.getElementById('myCanvas');
  this.canvasCtx = this.canvas.getContext('2d');
  this.WIDTH = 500;
  this.HEIGHT = 300;
  this.bufferLength = 0;
  this.lineArray = [];
  this.move = 0;
  this.movex = this.WIDTH - 1;

  this.createContext();
};

PCMPlayer.prototype.getMaxValue = function () {
  const encodings = {
    '8bitInt': 128,
    '16bitInt': 32768,
    '32bitInt': 2147483648,
    '32bitFloat': 1,
  };

  return encodings[this.option.encoding] ? encodings[this.option.encoding] : encodings['16bitInt'];
};

PCMPlayer.prototype.getTypedArray = function () {
  const typedArrays = {
    '8bitInt': Int8Array,
    '16bitInt': Int16Array,
    '32bitInt': Int32Array,
    '32bitFloat': Float32Array,
  };

  return typedArrays[this.option.encoding]
    ? typedArrays[this.option.encoding]
    : typedArrays['16bitInt'];
};

PCMPlayer.prototype.createContext = function () {
  this.audioCtx = new (window.AudioContext || window.webkitAudioContext)();

  //音频分析
  this.analyser = this.audioCtx.createAnalyser();
  this.analyser.smoothingTimeConstant = 0.001;
  this.analyser.fftSize = 32;
  this.analyser.connect(this.audioCtx.destination);
  this.frequency = new Uint8Array(this.analyser.frequencyBinCount);
  console.log(this.analyser.frequencyBinCount);
  this.bufferLength = this.analyser.frequencyBinCount;
  this.startTime = this.audioCtx.currentTime;

  setInterval(() => {
    this.draw();
  }, 100);
};

PCMPlayer.prototype.draw = function () {
  window.requestAnimationFrame(() => {
    this.redraw(-10);
    this.drawLine(0);
  });
};

PCMPlayer.prototype.isTypedArray = function (data) {
  return data.byteLength && data.buffer && data.buffer.constructor == ArrayBuffer;
};

PCMPlayer.prototype.feed = function (data) {
  //   if (!this.isTypedArray(data)) return;

  data = this.getFormatedValue(data);
  const tmp = new Float32Array(this.samples.length + data.length);
  tmp.set(this.samples, 0);
  tmp.set(data, this.samples.length);
  this.samples = tmp;
};

PCMPlayer.prototype.getFormatedValue = function (data) {
  if (data.constructor == ArrayBuffer) {
    data = new this.typedArray(data);
  } else {
    data = new this.typedArray(data.buffer);
  }

  let float32 = new Float32Array(data.length);

  for (let i = 0; i < data.length; i++) {
    // buffer 缓冲区的数据，需要是IEEE754 里32位的线性PCM，范围从-1到+1
    // 所以对数据进行除法
    // 除以对应的位数范围，得到-1到+1的数据
    // float32[i] = data[i] / 0x8000;
    float32[i] = data[i] / this.maxValue;
  }
  return float32;
};

PCMPlayer.prototype.destroy = function () {
  if (this.interval) {
    clearInterval(this.interval);
  }
  this.samples = null;
  this.audioCtx.close();
  this.audioCtx = null;
};

PCMPlayer.prototype.flush = function () {
  console.log('in flush', this.samples.length);
  if (!this.samples.length) return;
  const bufferSource = this.audioCtx.createBufferSource();
  const length = this.samples.length / this.option.channels;
  const audioBuffer = this.audioCtx.createBuffer(
    this.option.channels,
    length,
    this.option.sampleRate,
  );

  let audioData;
  let channel;
  let offset;
  let i;
  let decrement;

  for (channel = 0; channel < this.option.channels; channel++) {
    audioData = audioBuffer.getChannelData(channel);
    offset = channel;
    decrement = 50;
    for (i = 0; i < length; i++) {
      audioData[i] = this.samples[offset];
      /* fadein */
      if (i < 50) {
        audioData[i] = (audioData[i] * i) / 50;
      }
      /* fadeout*/
      if (i >= length - 51) {
        audioData[i] = (audioData[i] * decrement--) / 50;
      }
      offset += this.option.channels;
    }
  }

  if (this.startTime < this.audioCtx.currentTime) {
    this.startTime = this.audioCtx.currentTime;
  }
  console.log(
    'start vs current ' +
      this.startTime +
      ' vs ' +
      this.audioCtx.currentTime +
      ' duration: ' +
      audioBuffer.duration,
  );
  bufferSource.buffer = audioBuffer;
  bufferSource.connect(this.analyser);
  bufferSource.start(this.startTime);
  this.startTime += audioBuffer.duration;
  this.samples = new Float32Array();
};

//画波形线
PCMPlayer.prototype.drawLine = function (movex) {
  this.canvasCtx.save();
  this.analyser.getByteFrequencyData(this.frequency);

  for (let i = 0, length = this.bufferLength; i < length; i++) {
    const v = this.frequency[i] / 512.0;
    const y = (v * this.HEIGHT) / 2;
    y = y > 1 ? y : 1;
    const m = this.HEIGHT / 2;
    const h = y;
    const sy = m + h / 2;
    const ey = m - h / 2;
    this.canvasCtx.beginPath();
    this.canvasCtx.lineWidth = 1;
    this.canvasCtx.strokeStyle = 'red';
    this.canvasCtx.moveTo(this.movex, sy);
    this.canvasCtx.lineTo(this.movex, ey);
    this.canvasCtx.stroke();
    this.canvasCtx.closePath();
    this.lineArray.push({
      sx: this.movex,
      sy: sy,
      ex: this.movex,
      ey: ey,
    });
  }
  this.canvasCtx.restore();
};

/**
 * 每次重绘向后移动的位置
 * @param x
 */
PCMPlayer.prototype.redraw = function (x) {
  //清除过多的数据
  const l = this.WIDTH * this.bufferLength;
  if (this.lineArray.length > l) {
    const rmCount = this.lineArray.length - l;
    this.lineArray.splice(0, rmCount);
  }

  //重绘
  this.canvasCtx.clearRect(0, 0, this.WIDTH, this.HEIGHT);
  this.canvasCtx.fillStyle = '#0cc';
  this.canvasCtx.fillRect(0, 0, this.WIDTH, this.HEIGHT);
  this.lineArray.forEach((a, b) => {
    a.sx += x;
    a.ex += x;
    this.canvasCtx.beginPath();
    this.canvasCtx.lineWidth = 1;
    this.canvasCtx.strokeStyle = 'red';
    this.canvasCtx.moveTo(a.sx, a.sy);
    this.canvasCtx.lineTo(a.ex, a.ey);
    this.canvasCtx.stroke();
    this.canvasCtx.closePath();
  });
};
