import React from 'react';
import { Link } from 'umi';
import StreamPlayer from './streamPlayer';
import styles from './index.css';

function Index() {
  return (
    <div className={styles.normal}>
      <Link to="/">go</Link>
      <hr style={{ width: '100%' }} />
      <StreamPlayer autoStart />
      <hr style={{ width: '100%' }} />
    </div>
  );
}

export default Index;
